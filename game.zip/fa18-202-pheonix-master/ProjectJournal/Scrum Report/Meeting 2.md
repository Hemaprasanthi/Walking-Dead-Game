# Scrum Report

Date: 2018-11-14

## Stand-up Questions

1. What tasks did I work on / complete?


*Kriti: Done with unit test cases and use case diagrams. Suggested some of the changes if the diagram

*Ruchika: Decided design pattern for the score. Discussed class and sequence diagram with the whole team.

*Hema: On a high level discussed the design patterns to be implemented with the team. Made contribution to the diagram

*Harsh: Planning design pattern for the score and more patterns that might be used. Changed the some of the functionality.


2. What am I planning to work on next?

*Ruchika: Update README.md files

*Harsh: Design pattern implementation

*Kriti: Decide design pattern for the functionality and start working on class diagram.

*Hema: UML diagram (Sequence) to determine the flow.


3. What tasks are blocked waiting on another team member?

* No blockers as of now

## XP Core Values

- Communication


- Simplicity


- Feedback


- Courage


- Respect

