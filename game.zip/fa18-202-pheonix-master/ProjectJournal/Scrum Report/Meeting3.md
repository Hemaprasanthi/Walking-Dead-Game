# Scrum Report
Date: 2018-11-21

## Stand-up Questions
What tasks did I work on / complete?

*Kriti: Done with sword functionality using state pattern. Removed the error in message display by implementing singleton pattern for item collection observer and message 

*Ruchika: Completed initial setup and implemented observer pattern to collecting items

*Hema: Implemented strategy pattern to human and zombie movement

*Harsh: Developed state pattern for human state

What am I planning to work on next?
*Ruchika: Add gun functionality and work on facade pattern

*Harsh: Imporve API
*Kriti: Implement increasing the levels of games and increasing complexity and work on facade pattern

*Hema: Remove glitches of gun funtionality

What tasks are blocked waiting on another team member?
No blockers as of now

## XP Core Values
Communication: Team is effectively communicating over phone and meeting regularly

Simplicity: Till now, team has worked on every task with simplicity 

Feedback: Everyone gives their feedback and tries to improvise the code as per the feedback.

Courage: Though team is lagging little in finishing task but everyone is working hard to beat the deadline and present the demo perfectly.

Respect: All are talking to each other with respect and take others opinion without hesitation
