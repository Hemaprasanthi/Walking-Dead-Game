Scrum Report
Date: 2018-11-07

Stand-up Questions

       
Que: What tasks did I work on / complete?


Harsh: Created the User Story, Sub task, Issues and Project Board in GitHub
         Edited Google Sheets for Burndown chart with task break down and hours
         Built datamodel and database schema
         Designed the system sequence diagram and use case diagram

Ruchika: Created the User Story, Sub task, Issues and Project Board in GitHub
         Edited Google Sheets for Burndown chart with task break down and hours
         Built datamodel and database schema
         Designed the system sequence diagram and use case diagram

Hema:    Created the User Story, Sub task, Issues and Project Board in GitHub
         Edited Google Sheets for Burndown chart with task break down and hours
         Built datamodel and database schema
         Designed the system sequence diagram and use case diagram

Kriti:   Created the User Story, Sub task, Issues and Project Board in GitHub
         Updated Google Sheets for Burndown chart with task break down and hours
         Designed the system sequence diagram and use case diagram

Que: What am I planning to work on next?

Ruchika: Create unit test cases

Harsh: Create strategy for project run

Kriti: Create Unit Test Cases and finish use case diagrams.

Hema:  Determine design patterns involved in the process


Que: What tasks are blocked waiting on another team member?

Decide the design patterns to be used and assign each member one functionality.

Que: XP Core Values:

With other core values, we will be focusing on communication as our prime value and will make sure that we follow it sincerely in our project.

Communication
Team is full of dedicated professionals, who reach out to each other regarding technical issues and process flow, over a phone call and in scrum meetings, thus resolving them quickly and move forward. Everyone values others point of view and reach to a common conclusion in case of any difference of views with proper communication.

