import greenfoot.*;  //(World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Kit extends Actor
{
    public Kit(){
        GreenfootImage image1 = new GreenfootImage("firstaid.png");
        image1.scale(image1.getWidth() - 10, image1.getHeight() - 10);
        setImage(image1);
    }
    
    /**
     * Act of Kit
     */
    
    public void act(){}    
}
