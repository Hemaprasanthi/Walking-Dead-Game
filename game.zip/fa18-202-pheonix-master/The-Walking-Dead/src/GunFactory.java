import greenfoot.*;

public class GunFactory  extends Creator
{
    public Actor getActor(){
    return new Gun();
    }
}
