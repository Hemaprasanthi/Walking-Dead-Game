public interface iItemCollectionFacade 
{
    public  void doAction();
}
