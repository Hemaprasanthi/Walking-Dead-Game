import greenfoot.*;

public abstract class Creator{
    public abstract Actor getActor();
}