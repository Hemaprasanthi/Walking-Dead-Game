/** 
 * Write a description of class Observer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Observer  
{
 void update(String item, Message m);
}