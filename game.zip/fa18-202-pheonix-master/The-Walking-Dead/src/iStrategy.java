import greenfoot.*; 


public interface iStrategy{
    void movement(Actor a);
}