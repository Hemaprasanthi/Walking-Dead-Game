import greenfoot.*;  //(World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class FinalBanner extends Actor //this actor(image) is for displaying whether the player has won or lost.
{
    public FinalBanner(String image){
        setImage(image);
    }
    
    /**
     * Act of FinalBanner
     */
    public void act(){}    
}
