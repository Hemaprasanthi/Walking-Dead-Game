import greenfoot.*;

public class KitFactory  extends Creator
{
    public Actor getActor(){
    return new Kit();
    }
}
