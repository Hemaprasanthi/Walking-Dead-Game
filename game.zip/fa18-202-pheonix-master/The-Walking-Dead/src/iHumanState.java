public interface iHumanState  
{
    public void setState();
    public void display();
}
