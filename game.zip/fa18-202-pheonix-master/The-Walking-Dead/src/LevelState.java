/**
 * Write a description of class LevelState here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import greenfoot.*;
public interface LevelState  
{
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void doAction(World world);

}
