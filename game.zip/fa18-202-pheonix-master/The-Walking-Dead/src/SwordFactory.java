import greenfoot.*;

public class SwordFactory  extends Creator
{
    public Actor getActor(){
    return new Sword();
    }
}
