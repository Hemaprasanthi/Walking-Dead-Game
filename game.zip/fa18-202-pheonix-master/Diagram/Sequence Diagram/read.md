# Sequence diagrams

Sequence diagrams for following functionalities:

1) Human collects food and message actor is updated with increase in count of food.

2) Gun sequence diagram that depicts the gun functionality. When human has gun, it can fire bullet and if it hits zombie, then zombie dies and message is updated.

3) Kit sequence diagram: When human collects kit, he gets one life and even if he hits zombie, he doesnt die. 

4) Sword sequence diagram includes human collecting sword and hitting zombie when he has two parts of sword. Zombied then dies.


